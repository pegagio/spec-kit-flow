---
name: flow-kit-plan
description: Create reviewed technical planning artifacts. Run the installed speckit-flow-plan workflow in this Codex task.
---

# FlowKit Plan

Run only the installed `speckit-flow-plan` workflow in the selected consumer project and current Codex task. Follow `.specify/flow-kit/controller-protocol.md` exactly. The installed workflow owns its prompts, commands, branch logic, and gates; do not duplicate them here or call `specify workflow run`. Start by validating the installed controller inventory and invoking `bash .specify/flow-kit/scripts/bootstrap.sh "$PWD" speckit-flow-plan flow-kit-plan` from the consumer project. Translate supplied workflow inputs to repeated `--input name=value` arguments and the optional single named-step model/effort override to repeated `--override name=value` arguments on the bootstrap command. Show the effective assignment table and stop before workflow execution if any input or model-effort pair is invalid or unavailable. Do not launch another workflow phase.
